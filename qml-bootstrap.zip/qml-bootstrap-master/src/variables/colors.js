
var color = {
    light: "#fff",
    stable: "#f8f8f8",
    positive: "#4a87ee",
    calm: "#43cee6",
    balanced: "#66cc33",
    energized: "#f0b840",
    assertive: "#ef4e3a",
    royal: "#8a6de9",
    dark: "#444"
}
